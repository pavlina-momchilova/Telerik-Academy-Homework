﻿namespace ClassOneTwoThreeInCSharp
{
    using System;

    public class PrintBoolAsString
    {
        internal void PrintBooleanAsString(bool boolean)
        {
            string booleanAsString = boolean.ToString();
            Console.WriteLine(booleanAsString);
        }
    }
}
