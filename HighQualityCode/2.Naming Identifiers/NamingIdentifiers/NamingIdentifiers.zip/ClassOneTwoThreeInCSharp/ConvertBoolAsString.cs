﻿namespace ClassOneTwoThreeInCSharp
{
    public class ConvertBoolAsString
    {
        public static void Main()
        {
            PrintBoolAsString boolean = new PrintBoolAsString();
            boolean.PrintBooleanAsString(true);
        }
    }
}
