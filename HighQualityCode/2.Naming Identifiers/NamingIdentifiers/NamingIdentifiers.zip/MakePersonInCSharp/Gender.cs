﻿namespace MakePersonInCSharp
{
    public enum Gender 
    {
        Man, Female
    }
}
