﻿/*
 Write an expression that calculates rectangle’s area 
 by given width and height.
 */
var width = [3, 2.5, 5];
var height = [4, 3, 5];

for (var i = 0; i < width.length; i++) {
    console.log('width = ' + width[i] + ' height = ' + height[i] + ' area = ' + (width[i] * height[i]));
}